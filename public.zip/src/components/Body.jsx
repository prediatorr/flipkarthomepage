import React from "react";
import Carousel from "./Caraousel";
import Items from "./Items";
function Body() {
  return (
    <div className="">
      <Carousel />
      <Items />
    </div>
  );
}

export default Body;
